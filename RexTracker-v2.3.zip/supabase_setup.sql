-- Run this SQL once in Supabase Dashboard > SQL Editor.
-- The browser app intentionally has no service_role key; access is restricted by RLS.

create table if not exists public.habit_data (
  user_id uuid primary key references auth.users (id) on delete cascade,
  data jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.habit_data enable row level security;

-- Remove table access from unauthenticated visitors, then grant only the operations used by the app.
revoke all on table public.habit_data from public, anon;
grant usage on schema public to authenticated;
grant select, insert, update on table public.habit_data to authenticated;

-- Drop/recreate these policies so the script can be safely re-run.
drop policy if exists "Users can read their own habit data" on public.habit_data;
drop policy if exists "Users can insert their own habit data" on public.habit_data;
drop policy if exists "Users can update their own habit data" on public.habit_data;

create policy "Users can read their own habit data"
  on public.habit_data for select to authenticated
  using ((select auth.uid()) = user_id);

create policy "Users can insert their own habit data"
  on public.habit_data for insert to authenticated
  with check ((select auth.uid()) = user_id);

create policy "Users can update their own habit data"
  on public.habit_data for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
